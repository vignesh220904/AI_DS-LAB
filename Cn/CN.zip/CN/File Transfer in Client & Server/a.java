import java.io.*;
import java.net.*;

public class FileServer {
    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(12346)) {
            System.out.println("File Server is running...");
            Socket clientSocket = serverSocket.accept();
            System.out.println("Client connected");

            File file = new File("file_to_send.txt");
            FileInputStream fis = new FileInputStream(file);
            OutputStream os = clientSocket.getOutputStream();
            byte[] buffer = new byte[4096];
            int bytesRead;

            while ((bytesRead = fis.read(buffer)) != -1) {
                os.write(buffer, 0, bytesRead);
            }

            fis.close();
            os.close();
            clientSocket.close();
            System.out.println("File sent successfully");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


import java.io.*;
import java.net.*;

public class FileClient {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 12346)) {
            InputStream is = socket.getInputStream();
            FileOutputStream fos = new FileOutputStream("received_file.txt");
            byte[] buffer = new byte[4096];
            int bytesRead;

            while ((bytesRead = is.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
            }

            fos.close();
            System.out.println("File received successfully");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


