import java.util.*;

public class LinkStateRouting {
    static final int INF = Integer.MAX_VALUE;
    static final int N = 4; // Number of nodes in the network

    public static void main(String[] args) {
        int[][] dist = {
            {0, 1, INF, 3},
            {1, 0, 2, INF},
            {INF, 2, 0, 4},
            {3, INF, 4, 0}
        };

        int[][] costs = new int[N][N];
        for (int i = 0; i < N; i++) {
            Arrays.fill(costs[i], INF);
            costs[i][i] = 0;
        }

        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (dist[i][j] != INF) {
                    costs[i][j] = dist[i][j];
                }
            }
        }

        for (int k = 0; k < N; k++) {
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    if (costs[i][k] + costs[k][j] < costs[i][j]) {
                        costs[i][j] = costs[i][k] + costs[k][j];
                    }
                }
            }
        }

        System.out.println("Shortest paths:");
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                System.out.printf("%4d ", costs[i][j] == INF ? 999 : costs[i][j]);
            }
            System.out.println();
        }
    }
}
