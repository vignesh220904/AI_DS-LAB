import java.io.*;
import java.net.*;

public class DNSServer {
    public static void main(String[] args) {
        DatagramSocket socket = null;

        try {
            socket = new DatagramSocket(53);
            byte[] buffer = new byte[512];

            while (true) {
                DatagramPacket requestPacket = new DatagramPacket(buffer, buffer.length);
                socket.receive(requestPacket);

                String request = new String(requestPacket.getData(), 0, requestPacket.getLength());
                System.out.println("Received request: " + request);

                String response = "127.0.0.1";  // Simulate DNS resolution to localhost
                DatagramPacket responsePacket = new DatagramPacket(response.getBytes(), response.length(), requestPacket.getAddress(), requestPacket.getPort());
                socket.send(responsePacket);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        }
    }
}


import java.io.*;
import java.net.*;

public class DNSClient {
    public static void main(String[] args) {
        DatagramSocket socket = null;

        try {
            socket = new DatagramSocket();
            String query = "example.com";
            DatagramPacket requestPacket = new DatagramPacket(query.getBytes(), query.length(), InetAddress.getByName("localhost"), 53);
            socket.send(requestPacket);

            byte[] buffer = new byte[512];
            DatagramPacket responsePacket = new DatagramPacket(buffer, buffer.length);
            socket.receive(responsePacket);

            String response = new String(responsePacket.getData(), 0, responsePacket.getLength());
            System.out.println("Received response: " + response);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        }
    }
}
